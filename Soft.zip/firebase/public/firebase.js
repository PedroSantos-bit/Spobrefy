// firebase/firebase.js
/*import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

// 🔁 Substitua os valores abaixo pelas suas credenciais do Firebase Web
const firebaseConfig = {
  apiKey: "AIzaSyAr5JvCJWfgzzfCnjCVqGamZajwS7TLgX8",
  authDomain: "http://soft-music-6ef73.firebaseapp.com/",
  projectId: "soft-music-6ef73",
  storageBucket: "soft-music-6ef73.appspot.com",
  messagingSenderId: "966720969751",                // ✅ Adicionado
  appId: "1:966720969751:web:SEU_ID_AQUI",
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

export { auth };*/
